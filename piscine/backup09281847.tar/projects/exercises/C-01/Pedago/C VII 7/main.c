#include <stdio.h>

/*void fct(int a)
{
	a = a + 42;
}

int main(void)
{
	int a;

	a = 42;
	printf("%d\n", a);
	fct(a);
	printf("%d\n", a);
	return (0);
}*/

/*void fct(int *a)
{
	*a = *a + 42;
}

int main(void)
{
	int a;

	a = 42;
	printf("%d\n", a);
	fct(&a);
	printf("%d\n", a);
	return (0);
}*/

int main(void)
{
	int *ptr;

	ptr = 42;
	return (0);
}
