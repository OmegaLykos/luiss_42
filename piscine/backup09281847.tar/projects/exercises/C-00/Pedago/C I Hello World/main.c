#include <stdio.h>

int main()
{
	printf("hello world\n");
	printf("hello pouet\n");
}
