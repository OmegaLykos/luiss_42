#include <stdio.h>

int main()
{
	int a;
	int b;

	a = 43;
	b = 43;
	printf("%d == %d %d\n", a, b, a == b);
}

// == !=i >= <= ! && ||
