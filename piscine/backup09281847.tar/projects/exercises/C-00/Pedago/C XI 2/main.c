void	fct();
void	fct2();

int main(void)
{
	fct2();
	fct2();
	fct2();
	fct2();
	fct2();
	return (0);
}
