#include <stdio.h>
#include "secret.h"

int main()
{
	char 	 c;

	c = 11;
	c2 = 6;
	off_bin(c);
	off_bin(c2);
	printf("! \n");
	off_bin(!c);
}

//Gli Operatori Binari & | ^ ~ !
//
// << >>
