#include <stdio.h>

int main()
{
	int i;
	int a;

	i = 42;
	a = 12;
	printf("%d\n", --i +a);
	printf("%d\n", i);
}
