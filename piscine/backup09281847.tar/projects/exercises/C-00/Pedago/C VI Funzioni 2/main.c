#include <stdio.h>

void fct(void);

int main (void)
{
	fct();
	fct();
	fct();
	return(0);
}
