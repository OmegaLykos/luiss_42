#include <stdio.h>

void fct(void)
{
	printf("Coucou42\n");
}
