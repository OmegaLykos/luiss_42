#include <stdio.h>

/*int main()
{
	char	c;

	c = 'k';
	printf("%lu %d %c\n", sizeof(c), c, c);	
}*/

/*int main()
{
	int i;

	printf("%lu\n", sizeof(i));
}*/

int main()
{
	char	c;
	int		i;
	float	f;
	double	d;

	f = 12.37;
	printf("%lu \n", sizeof(d));
}

