#include <stdio.h>

int main()
{
	int	i;
	int	tab[1];

	i = 67;
	tab[1] = 1;
	tab[2] = 1;
	tab[3] = 1;
	tab[4] = 1;
	tab[5] = 1;
	tab[6] = 1;
	tab[7] = 1;
	tab[8] = 1;
	tab[9] = 1;
	tab[10] = 1;
	printf("%d\n", i);
}
