#include <stdio.h>

int main()
{
	int i;

	i = 10;
	do
	{
		printf("%d\n", i);
		i++;
	}
	while (i < 10);
}
