#include <stdio.h>

int a;

int main()
{
	{
		a = 42;
	}
	printf("%d\n", a);
}
