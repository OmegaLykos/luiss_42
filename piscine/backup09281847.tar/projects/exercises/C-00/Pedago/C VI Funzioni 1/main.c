#include <stdio.h>

void fct(void)
{
	printf("Coucou 42\n");
	printf("Coucou \n");
}

int main (void)
{
	fct();
	fct();
	fct();
	return(0);
}
